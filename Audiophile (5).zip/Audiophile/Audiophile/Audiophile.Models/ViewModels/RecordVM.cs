﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;

namespace Audiophile.Models.ViewModels
{
    public class RecordVM
    {
        public Record Record { get; set; }
        public IEnumerable<SelectListItem> GenreList { get; set; }
        public IEnumerable<SelectListItem> StockList { get; set; }



    }
}
