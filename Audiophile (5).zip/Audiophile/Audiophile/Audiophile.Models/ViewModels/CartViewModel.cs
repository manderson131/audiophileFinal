﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Audiophile.Models.ViewModels
{
    public class CartViewModel
    {
        public IList<Record> RecordList { get; set; }
        public OrderHeader OrderHeader { get; set; }
    }
}
