﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.Linq;
using Microsoft.Bot.Builder.AI.QnA;

namespace Audiophile
{
    public class EchoBot
    {
        public QnAMaker EchoBotQnA { get; private set; }
        public EchoBot(QnAMakerEndpoint endpoint)
        {
            // connects to QnA Maker endpoint for each turn
            EchoBotQnA = new QnAMaker(endpoint);
        }


        private async Task AccessQnAMaker(Microsoft.Bot.Builder.ITurnContext<Microsoft.Bot.Schema.IMessageActivity> turnContext, System.Threading.CancellationToken cancellationToken)
        {
            var results = await EchoBotQnA.GetAnswersAsync(turnContext);
            if (results.Any())
            {
                await turnContext.SendActivityAsync(Microsoft.Bot.Builder.MessageFactory.Text("QnA Maker Returned: " + results.First().Answer), cancellationToken);
            }
            else
            {
                await turnContext.SendActivityAsync(Microsoft.Bot.Builder.MessageFactory.Text("Sorry, could not find an answer in the Q and A system."), cancellationToken);
            }
        }

        protected async Task OnMessageActivityAsync(
            Microsoft.Bot.Builder.ITurnContext<Microsoft.Bot.Schema.IMessageActivity> turnContext,
            System.Threading.CancellationToken cancellationToken)
        {
            await turnContext.SendActivityAsync(Microsoft.Bot.Builder.MessageFactory.Text($"Echo: {turnContext.Activity.Text}"), cancellationToken);

            await AccessQnAMaker(turnContext, cancellationToken);
        }




    }
}
