﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Audiophile.DataAccess.Data.Repository.IRepository;
using Audiophile.Models;
using Audiophile.Models.ViewModels;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;

namespace Audiophile.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class RecordController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IWebHostEnvironment _hostEnvironment;

        [BindProperty]
        public RecordVM ServVM { get; set; }

        public RecordController(IUnitOfWork unitOfWork, IWebHostEnvironment hostEnvironment)
        {
            _unitOfWork = unitOfWork;
            _hostEnvironment = hostEnvironment;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Upsert(int? id)
        {
            ServVM = new RecordVM()
            {
                Record = new Models.Record(),
                GenreList = _unitOfWork.Genre.GetGenreListForDropDown(),
                StockList = _unitOfWork.Stock.GetStockListForDropDown(),
            };
            if (id != null)
            {
                ServVM.Record = _unitOfWork.Record.Get(id.GetValueOrDefault());
            }

            return View(ServVM);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Upsert()
        {
            if (ModelState.IsValid)
            {
                string webRootPath = _hostEnvironment.WebRootPath;
                var files = HttpContext.Request.Form.Files;
                if (ServVM.Record.Id == 0)
                {
                    //New Record
                    string fileName = Guid.NewGuid().ToString();
                    var uploads = Path.Combine(webRootPath, @"images\services");
                    var extension = Path.GetExtension(files[0].FileName);

                    using (var fileStreams = new FileStream(Path.Combine(uploads, fileName + extension), FileMode.Create))
                    {
                        files[0].CopyTo(fileStreams);
                    }
                    ServVM.Record.ImageUrl = @"\images\services\" + fileName + extension;

                    _unitOfWork.Record.Add(ServVM.Record);
                }
                else
                {
                    //Edit Service
                    var serviceFromDb = _unitOfWork.Record.Get(ServVM.Record.Id);
                    if (files.Count > 0)
                    {
                        string fileName = Guid.NewGuid().ToString();
                        var uploads = Path.Combine(webRootPath, @"images\services");
                        var extension_new = Path.GetExtension(files[0].FileName);

                        var imagePath = Path.Combine(webRootPath, serviceFromDb.ImageUrl.TrimStart('\\'));
                        if (System.IO.File.Exists(imagePath))
                        {
                            System.IO.File.Delete(imagePath);
                        }

                        using (var fileStreams = new FileStream(Path.Combine(uploads, fileName + extension_new), FileMode.Create))
                        {
                            files[0].CopyTo(fileStreams);
                        }
                        ServVM.Record.ImageUrl = @"\images\services\" + fileName + extension_new;
                    }
                    else
                    {
                        ServVM.Record.ImageUrl = serviceFromDb.ImageUrl;
                    }

                    _unitOfWork.Record.Update(ServVM.Record);
                }
                _unitOfWork.Save();
                return RedirectToAction(nameof(Index));
            }
            else
            {
                ServVM.GenreList = _unitOfWork.Genre.GetGenreListForDropDown();
                ServVM.StockList = _unitOfWork.Stock.GetStockListForDropDown();
                return View(ServVM);
            }
        }



        #region API Calls
        public IActionResult GetAll()
        {
            return Json(new { data = _unitOfWork.Record.GetAll(includeProperties: "Genre,Stock") });
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var serviceFromDb = _unitOfWork.Record.Get(id);
            string webRootPath = _hostEnvironment.WebRootPath;
            var imagePath = Path.Combine(webRootPath, serviceFromDb.ImageUrl.TrimStart('\\'));
            if (System.IO.File.Exists(imagePath))
            {
                System.IO.File.Delete(imagePath);
            }

            if (serviceFromDb == null)
            {
                return Json(new { success = false, message = "Error while deleting." });
            }

            _unitOfWork.Record.Remove(serviceFromDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Deleted Successfully." });
        }

        #endregion
    }
}