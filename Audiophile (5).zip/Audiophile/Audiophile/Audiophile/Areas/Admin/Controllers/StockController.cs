﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Audiophile.DataAccess.Data.Repository.IRepository;
using Audiophile.Models;
using Microsoft.AspNetCore.Mvc;

namespace Audiophile.Areas.Admin.Controllers
{

    [Area("Admin")]
    public class StockController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public StockController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IActionResult Index()
        {
            return View();
        }


        // GET: Contacts/Upsert/5
        public IActionResult Upsert(int? id)
        {
            Stock stock = new Stock();
            if (id == null)
            {

                return View(stock);
            }

            stock = _unitOfWork.Stock.Get(id.GetValueOrDefault());
            if (stock == null)
            {
                return NotFound();
            }
            return View(stock);
        }

        // POST: Contacts/Upsert/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Upsert(Stock stock)
        {

            if (ModelState.IsValid)
            {
                if (stock.Id == 0)
                {
                    _unitOfWork.Stock.Add(stock);
                }
                else
                {
                    _unitOfWork.Stock.Update(stock);
                }
                _unitOfWork.Save();
                return RedirectToAction(nameof(Index));
            }
            return View(stock);

        }


        #region API Calls

        public IActionResult GetAll()
        {

            return Json(new { data = _unitOfWork.Stock.GetAll() });
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var objFromDb = _unitOfWork.Stock.Get(id);
            if (objFromDb == null)
            {
                return Json(new { success = false, message = "Error while deleting." });
            }
            _unitOfWork.Stock.Remove(objFromDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Delete successful." });

        }
        #endregion
    }
}
