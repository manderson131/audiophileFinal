﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Audiophile.DataAccess.Data.Repository.IRepository;
using Audiophile.Models;
using Microsoft.AspNetCore.Mvc;

namespace Audiophile.Areas.Admin.Controllers
{
    [Area ("Admin")]
    public class GenreController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public GenreController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }


        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Upsert(int? id)
        {
            Genre genre = new Genre();
            if (id == null)
            {
                return View(genre);
            }
            genre = _unitOfWork.Genre.Get(id.GetValueOrDefault());

            if (genre == null)
            {
                return NotFound();
            }
            return View(genre);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Upsert(Genre genre)
        {
            if(ModelState.IsValid)
            {
                if(genre.Id==0)
                {
                    _unitOfWork.Genre.Add(genre);
                }
                else
                {
                    _unitOfWork.Genre.Update(genre);
                }
                _unitOfWork.Save();
                return RedirectToAction(nameof(Index));
            }
            return View(genre);
        }







        #region API Calls
        [HttpGet]
        public IActionResult GetAll()
        {
            return Json(new { data = _unitOfWork.Genre.GetAll() });
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var objFromDb = _unitOfWork.Genre.Get(id);
            if (objFromDb == null)
            {
                return Json(new { Success = false, message = "Error while Deleting." });
            }

            _unitOfWork.Genre.Remove(objFromDb);
            _unitOfWork.Save();
            return Json(new { Success = true, message = "Deleted Successful." });


        }


        #endregion 
    }
}