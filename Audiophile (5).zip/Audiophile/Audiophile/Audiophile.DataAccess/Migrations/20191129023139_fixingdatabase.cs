﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Audiophile.DataAccess.Migrations
{
    public partial class fixingdatabase : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Comments",
                table: "OrderHeader",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ZipCode",
                table: "OrderHeader",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Comments",
                table: "OrderHeader");

            migrationBuilder.DropColumn(
                name: "ZipCode",
                table: "OrderHeader");
        }
    }
}
