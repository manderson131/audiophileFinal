﻿using Audiophile.DataAccess.Data.Repository.IRepository;
using Audiophile.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Audiophile.DataAccess.Data.Repository
{
    public class GenreRepository : Repository<Genre>, IGenreRepository
    {
        private readonly ApplicationDbContext _db;

        public GenreRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetGenreListForDropDown()
        {
            return _db.Genre.Select(i => new SelectListItem()
            {
                Text = i.Name,
                Value = i.Id.ToString()
            });


        }

        public void Update(Genre genre)
        {
            var objFromDb = _db.Genre.FirstOrDefault(s => s.Id == genre.Id);

            objFromDb.Name = genre.Name;

            objFromDb.DisplayOrder = genre.DisplayOrder;

            _db.SaveChanges();

        }
    }
}
