﻿using Audiophile.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;

namespace Audiophile.DataAccess.Data.Repository.IRepository
{
    public interface IRecordRepository : IRepository<Record>
    {

        void Update(Record record);




    }
}
