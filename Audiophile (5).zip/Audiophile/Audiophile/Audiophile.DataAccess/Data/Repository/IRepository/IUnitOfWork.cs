﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Audiophile.DataAccess.Data.Repository.IRepository
{
    public interface IUnitOfWork : IDisposable
    {
        IGenreRepository Genre { get; }

        IStockRepository Stock { get; }

        IRecordRepository Record { get; }

        IOrderHeaderRepository OrderHeader { get; }

        IOrderDetailsRepository OrderDetails { get; }

        IUserRepository User { get; }



        void Save();


    }
}
