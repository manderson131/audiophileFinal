﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Audiophile.DataAccess.Data.Repository.IRepository
{
    public interface IUserRepository
    {
        void LockUser(string userId);

        void UnLockUser(string userId);
    }
}
